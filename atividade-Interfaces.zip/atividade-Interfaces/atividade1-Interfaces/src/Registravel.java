public interface Registravel {
    void registrarEvento(String mensagem);
}
