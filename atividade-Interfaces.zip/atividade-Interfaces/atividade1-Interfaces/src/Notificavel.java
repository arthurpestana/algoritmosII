public interface Notificavel {
    void enviarNotificacao(String usuarioId, String mensagem);
}