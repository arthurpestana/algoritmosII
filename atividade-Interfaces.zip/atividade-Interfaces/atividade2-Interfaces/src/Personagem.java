public interface Personagem {
    void atacar(Personagem alvo);
    void receberDano(int dano);
    void equiparArma(Arma arma);
    void equiparArmadura(Armadura armadura);
}
